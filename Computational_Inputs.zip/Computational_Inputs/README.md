# Computational Input Files

This directory contains the calculation input files used for MgGa2O4, ZnGa2O4, CdGa2O4, and HgGa2O4 in the revised manuscript.

The files are provided to support the reproducibility of the first-principles, lattice-dynamical, and finite-temperature calculations.

## Directory Structure

The input files are organized by material:

- `MgGa2O4/`
- `ZnGa2O4/`
- `CdGa2O4/`
- `HgGa2O4/`

Each material directory contains the following subdirectories:

### `Elastic/`

Input files used for the elastic-property calculations.

### `DFPT_Born/`

Input files used for the density functional perturbation theory (DFPT) calculations of the dielectric tensor and Born effective charges.

### `2nd_3rd_IFC_Common_Settings/`

Common VASP settings used for the displaced-supercell calculations of both the second-order and third-order interatomic force constants (IFCs).

Because the same electronic-structure settings were used for the second- and third-order IFC calculations, only the following common input files are provided in this directory:

- `INCAR`
- `KPOINTS`

The corresponding second-order and third-order force-constant files are provided separately in the material datasets.

### `AIMD800/`

Input files used for the ab initio molecular dynamics (AIMD) simulations performed at 800 K.

These calculations were used to assess the finite-temperature structural stability of the four MGa2O4 compounds at the revised upper temperature limit.

## Notes

The structural-relaxation input and output files were already included in the previously uploaded material datasets and are therefore not duplicated here.




