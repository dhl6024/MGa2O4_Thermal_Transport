import numpy as np
import sys

try:
    # 读取 BTE.kappa 文件
    data = np.loadtxt('BTE.kappa')
    
    # 获取最后一行数据 (无论文件有几行，[-1] 永远代表最后一行)
    if data.ndim > 1:
        last_line = data[-1, :]
    else:
        last_line = data
        
    # 计算有多少个声子分支 (总列数减去第一列的迭代号，然后除以9)
    n_bands = (len(last_line) - 1) // 9
    
    # 提取三条声学支的 xx 方向热导率
    # 索引规律: 1 + 分支号 * 9
    k_a1 = last_line[1 + 0 * 9]  # 第 1 条声学支
    k_a2 = last_line[1 + 1 * 9]  # 第 2 条声学支
    k_a3 = last_line[1 + 2 * 9]  # 第 3 条声学支
    
    # 提取所有光学支的总和
    k_opt_total = 0.0
    for b in range(3, n_bands):  # 从第4个分支（索引3）一直循环到最后
        k_opt_total += last_line[1 + b * 9]
        
    # 计算总热导率
    total_k = k_a1 + k_a2 + k_a3 + k_opt_total
    
    # 打印结果
    print("=" * 50)
    print(f"总分支数: {n_bands}")
    print(f"总晶格热导率 (xx方向): {total_k:.4f} W/(m K)")
    print("-" * 50)
    print(f"第 1 条声学支 (TA1) : {k_a1:.4f} W/(m K)  占比: {k_a1/total_k*100:.2f}%")
    print(f"第 2 条声学支 (TA2) : {k_a2:.4f} W/(m K)  占比: {k_a2/total_k*100:.2f}%")
    print(f"第 3 条声学支 (LA)  : {k_a3:.4f} W/(m K)  占比: {k_a3/total_k*100:.2f}%")
    print(f"所有光学支总和 (Opt): {k_opt_total:.4f} W/(m K)  占比: {k_opt_total/total_k*100:.2f}%")
    print("=" * 50)

except Exception as e:
    print("读取文件出错，请确认当前目录下存在 BTE.kappa 文件。错误信息:", e)

