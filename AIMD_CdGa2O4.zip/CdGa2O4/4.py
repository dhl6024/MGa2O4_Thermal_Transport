import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib import font_manager as fm


# ============================================================
# 0. User settings
# ============================================================

TIME_STEP_FS = 1.0
TARGET_TEMP = 800.0

# Total AIMD = 5 ps
# First 1 ps = equilibration
# Remaining 4 ps = production
EQUIL_PS = 1.0

# Energy moving average
MOVING_WINDOW = 100

# RDF settings
RDF_DR = 0.02
RDF_STRIDE = 10

OUTPUT_NAME = "AIMD_800K_production_4ps"

# Common plotting ranges
TEMP_YLIM = (550, 1150)
MSD_YLIM = (0.0, 0.24)
RDF_YLIM = (0.0, 10.2)

ATOMIC_MASSES = {
    "Mg": 24.305,
    "Zn": 65.38,
    "Cd": 112.414,
    "Hg": 200.592,
    "Ga": 69.723,
    "O": 15.999
}


# ============================================================
# 1. Basic checks
# ============================================================

if not os.path.exists("OSZICAR"):
    raise FileNotFoundError("OSZICAR was not found.")

if not os.path.exists("XDATCAR"):
    raise FileNotFoundError("XDATCAR was not found.")


# ============================================================
# 2. Helper: extract values from OSZICAR
# ============================================================

def extract_value(line, key):

    pattern = (
        rf"(?<![A-Za-z0-9_])"
        rf"{re.escape(key)}"
        rf"\s*=\s*([-+0-9.Ee]+)"
    )

    match = re.search(pattern, line)

    if match:
        return float(match.group(1))

    return np.nan


# ============================================================
# 3. Read OSZICAR
# ============================================================

print("Reading OSZICAR ...")

steps = []
temps = []
total_energy = []

with open("OSZICAR", "r") as f:

    for line in f:

        if "T=" not in line:
            continue

        parts = line.split()

        try:
            step = int(parts[0])

        except (ValueError, IndexError):
            continue

        T = extract_value(line, "T")

        # IMPORTANT:
        # Keep the same energy definition as the original script.
        E = extract_value(line, "E")

        if np.isfinite(T) and np.isfinite(E):

            steps.append(step)
            temps.append(T)
            total_energy.append(E)


steps = np.asarray(steps, dtype=int)
temps = np.asarray(temps, dtype=float)
total_energy = np.asarray(total_energy, dtype=float)

if len(steps) == 0:
    raise RuntimeError(
        "No AIMD ionic-step data were found in OSZICAR."
    )


time_ps = (
    (steps - steps[0])
    * TIME_STEP_FS
    / 1000.0
)

print(f"OSZICAR steps : {len(steps)}")
print(f"Total time    : {time_ps[-1]:.3f} ps")


# ============================================================
# 4. Select production stage
# ============================================================

prod_mask_osz = (
    time_ps >= EQUIL_PS
)

time_prod = (
    time_ps[prod_mask_osz]
    - EQUIL_PS
)

temp_prod = temps[prod_mask_osz]

energy_prod = total_energy[prod_mask_osz]

if len(time_prod) == 0:
    raise RuntimeError(
        "No production-stage data were found in OSZICAR."
    )


# ============================================================
# 5. Moving average
# ============================================================

def moving_average_xy(
    x,
    y,
    window
):

    if len(y) < window:

        return (
            np.array([]),
            np.array([])
        )

    kernel = (
        np.ones(window)
        / window
    )

    x_ma = np.convolve(
        x,
        kernel,
        mode="valid"
    )

    y_ma = np.convolve(
        y,
        kernel,
        mode="valid"
    )

    return (
        x_ma,
        y_ma
    )


time_energy_ma, energy_prod_ma = moving_average_xy(
    time_prod,
    energy_prod,
    MOVING_WINDOW
)


# ============================================================
# 6. Read XDATCAR
# ============================================================

def read_xdatcar(
    filename="XDATCAR"
):

    with open(
        filename,
        "r"
    ) as f:

        lines = f.readlines()


    scale = float(
        lines[1].split()[0]
    )


    lattice = np.array([

        [
            float(x)
            for x in lines[i].split()[:3]
        ]

        for i in range(2, 5)

    ]) * scale


    species = (
        lines[5].split()
    )


    counts = [

        int(x)

        for x in lines[6].split()

    ]


    natoms = sum(
        counts
    )


    atom_species = []


    for element, number in zip(
        species,
        counts
    ):

        atom_species.extend(
            [element] * number
        )


    frames = []

    i = 7


    while i < len(lines):

        if (
            "configuration="
            in lines[i].lower()
        ):

            i += 1

            frame = []


            for _ in range(
                natoms
            ):

                frame.append([

                    float(x)

                    for x
                    in lines[i].split()[:3]

                ])

                i += 1


            frames.append(
                frame
            )

        else:

            i += 1


    return (

        lattice,

        species,

        counts,

        np.asarray(
            atom_species
        ),

        np.asarray(
            frames,
            dtype=float
        )

    )


print(
    "Reading XDATCAR ..."
)


(
    lattice,
    species,
    counts,
    atom_species,
    frac_wrapped
) = read_xdatcar()


nframes, natoms, _ = (
    frac_wrapped.shape
)


print(
    "Species       :",
    species
)

print(
    "Atom counts   :",
    counts
)

print(
    "Total atoms   :",
    natoms
)

print(
    "XDATCAR frames:",
    nframes
)


# ============================================================
# 7. XDATCAR time axis
# ============================================================

frame_time_ps = (

    np.arange(
        nframes
    )

    * TIME_STEP_FS

    / 1000.0

)


prod_idx = np.where(

    frame_time_ps
    >= EQUIL_PS

)[0]


if len(prod_idx) == 0:

    raise RuntimeError(
        "No production-stage XDATCAR frames were found."
    )


ref_idx = (
    prod_idx[0]
)


# ============================================================
# 8. Sequential PBC unwrapping
# ============================================================

print(
    "Performing sequential PBC unwrapping ..."
)


frac_unwrapped = np.zeros_like(
    frac_wrapped
)


frac_unwrapped[0] = (
    frac_wrapped[0]
)


for iframe in range(
    1,
    nframes
):

    delta = (

        frac_wrapped[iframe]

        - frac_wrapped[iframe - 1]

    )


    delta -= np.round(
        delta
    )


    frac_unwrapped[iframe] = (

        frac_unwrapped[iframe - 1]

        + delta

    )


cart = np.einsum(

    "fna,ab->fnb",

    frac_unwrapped,

    lattice

)


# ============================================================
# 9. Mass-weighted center-of-mass drift removal
# ============================================================

masses = np.array([

    ATOMIC_MASSES[element]

    for element
    in atom_species

])


total_mass = np.sum(
    masses
)


COM = np.sum(

    cart
    * masses[
        None,
        :,
        None
    ],

    axis=1

) / total_mass


COM_drift = (

    COM
    - COM[0]

)


cart_corrected = (

    cart

    - COM_drift[
        :,
        None,
        :
    ]

)


# ============================================================
# 10. Identify A-site cation
# ============================================================

M_candidates = [

    element

    for element
    in [
        "Mg",
        "Zn",
        "Cd",
        "Hg"
    ]

    if element
    in species

]


if len(M_candidates) != 1:

    raise RuntimeError(
        "Could not uniquely identify the A-site cation."
    )


M_element = (
    M_candidates[0]
)


plot_species = [

    M_element,

    "Ga",

    "O"

]


print(
    f"A-site element : {M_element}"
)


# ============================================================
# 11. Species-resolved MSD
# ============================================================

reference = (

    cart_corrected[
        ref_idx
    ]

)


disp = (

    cart_corrected[
        ref_idx:
    ]

    - reference[
        None,
        :,
        :
    ]

)


msd_time = (

    frame_time_ps[
        ref_idx:
    ]

    - frame_time_ps[
        ref_idx
    ]

)


msd_species = {}


for element in plot_species:

    mask = (

        atom_species
        == element

    )


    squared_displacement = np.sum(

        disp[
            :,
            mask,
            :
        ] ** 2,

        axis=2

    )


    msd_species[element] = np.mean(

        squared_displacement,

        axis=1

    )


# ============================================================
# 12. RDF
# ============================================================

def calculate_rdf(

    frac_frames,

    lattice,

    atom_species,

    species_A,

    species_B,

    frame_indices,

    dr=0.02

):

    idx_A = np.where(

        atom_species
        == species_A

    )[0]


    idx_B = np.where(

        atom_species
        == species_B

    )[0]


    volume = abs(

        np.linalg.det(
            lattice
        )

    )


    lattice_lengths = np.linalg.norm(

        lattice,

        axis=1

    )


    r_max = (

        0.5

        * np.min(
            lattice_lengths
        )

    )


    bins = np.arange(

        0.0,

        r_max + dr,

        dr

    )


    histogram = np.zeros(

        len(bins) - 1,

        dtype=float

    )


    nframes_used = 0


    for iframe in frame_indices:

        frac = (
            frac_frames[iframe]
        )


        coords_A = (
            frac[idx_A]
        )


        coords_B = (
            frac[idx_B]
        )


        delta = (

            coords_B[
                None,
                :,
                :
            ]

            - coords_A[
                :,
                None,
                :
            ]

        )


        delta -= np.round(
            delta
        )


        delta_cart = np.einsum(

            "...a,ab->...b",

            delta,

            lattice

        )


        distances = np.linalg.norm(

            delta_cart,

            axis=-1

        ).ravel()


        hist, _ = np.histogram(

            distances,

            bins=bins

        )


        histogram += hist

        nframes_used += 1


    r_inner = (
        bins[:-1]
    )


    r_outer = (
        bins[1:]
    )


    shell_volume = (

        (4.0 / 3.0)

        * np.pi

        * (

            r_outer**3

            - r_inner**3

        )

    )


    rho_B = (

        len(idx_B)

        / volume

    )


    ideal_counts = (

        nframes_used

        * len(idx_A)

        * rho_B

        * shell_volume

    )


    g_r = (

        histogram

        / ideal_counts

    )


    r = (

        r_inner
        + r_outer

    ) / 2.0


    return (
        r,
        g_r
    )


rdf_frames = np.arange(

    ref_idx,

    nframes,

    RDF_STRIDE

)


print(

    f"RDF uses {len(rdf_frames)} production frames."

)


r_MO, g_MO = calculate_rdf(

    frac_wrapped,

    lattice,

    atom_species,

    M_element,

    "O",

    rdf_frames,

    RDF_DR

)


r_GaO, g_GaO = calculate_rdf(

    frac_wrapped,

    lattice,

    atom_species,

    "Ga",

    "O",

    rdf_frames,

    RDF_DR

)


# ============================================================
# 13. Production-stage statistics
# ============================================================

T_mean = np.mean(
    temp_prod
)


T_std = np.std(
    temp_prod
)


print()

print(
    "============================================="
)

print(
    "AIMD 800 K structural-stability analysis"
)

print(
    "============================================="
)

print()

print(
    f"Material A-site element : {M_element}"
)

print(
    f"Number of atoms         : {natoms}"
)

print(
    f"Time step               : {TIME_STEP_FS:.3f} fs"
)

print(
    f"Target temperature      : {TARGET_TEMP:.1f} K"
)

print(
    f"Total AIMD time         : {time_ps[-1]:.3f} ps"
)

print(
    f"Equilibration excluded  : {EQUIL_PS:.3f} ps"
)

print(
    f"Production time         : {time_prod[-1]:.3f} ps"
)

print()

print(
    "Production-stage temperature"
)

print(
    f"Mean T                  : {T_mean:.2f} K"
)

print(
    f"Standard deviation      : {T_std:.2f} K"
)

print()

print(
    "Species-resolved MSD"
)


for element in plot_species:

    curve = (
        msd_species[element]
    )

    half = (
        len(curve)
        // 2
    )


    print(

        f"{element:>2s} final MSD            : "

        f"{curve[-1]:.6f} Å²"

    )


    print(

        f"{element:>2s} mean MSD (late half) : "

        f"{np.mean(curve[half:]):.6f} Å²"

    )


# ============================================================
# 14. Write summary
# ============================================================

summary_file = (

    OUTPUT_NAME

    + "_summary.txt"

)


with open(
    summary_file,
    "w"
) as f:

    f.write(
        "AIMD 800 K structural-stability analysis\n"
    )

    f.write(
        "=============================================\n\n"
    )

    f.write(
        f"Material A-site element : {M_element}\n"
    )

    f.write(
        f"Number of atoms         : {natoms}\n"
    )

    f.write(
        f"Time step               : {TIME_STEP_FS:.3f} fs\n"
    )

    f.write(
        f"Target temperature      : {TARGET_TEMP:.1f} K\n"
    )

    f.write(
        f"Total AIMD time         : {time_ps[-1]:.3f} ps\n"
    )

    f.write(
        f"Equilibration excluded  : {EQUIL_PS:.3f} ps\n"
    )

    f.write(
        f"Production time         : {time_prod[-1]:.3f} ps\n\n"
    )

    f.write(
        "Production-stage temperature\n"
    )

    f.write(
        f"Mean T                  : {T_mean:.2f} K\n"
    )

    f.write(
        f"Standard deviation      : {T_std:.2f} K\n\n"
    )

    f.write(
        "Species-resolved MSD\n"
    )


    for element in plot_species:

        curve = (
            msd_species[element]
        )

        half = (
            len(curve)
            // 2
        )


        f.write(

            f"{element:>2s} final MSD            : "

            f"{curve[-1]:.6f} Å²\n"

        )


        f.write(

            f"{element:>2s} mean MSD (late half) : "

            f"{np.mean(curve[half:]):.6f} Å²\n"

        )


# ============================================================
# 15. Origin-like plot style
# ============================================================

available_fonts = {

    f.name

    for f
    in fm.fontManager.ttflist

}


preferred_fonts = [

    "Times New Roman",

    "Liberation Serif",

    "Nimbus Roman",

    "DejaVu Serif"

]


PLOT_FONT = next(

    (

        font

        for font
        in preferred_fonts

        if font
        in available_fonts

    ),

    "DejaVu Serif"

)


print(
    f"Plot font      : {PLOT_FONT}"
)


M_COLORS = {

    "Mg": "#37AD6B",

    "Zn": "#1A6FDF",

    "Cd": "#F14040",

    "Hg": "#8000FF"

}


MAIN_COLOR = (
    M_COLORS[M_element]
)


# Shared colors
GA_COLOR = "#E6A000"

O_COLOR = "#62A8AC"


BLACK = "#000000"

DARK_GRAY = "#555555"


def lighten_color(

    color,

    amount=0.68

):

    rgb = np.array(

        mcolors.to_rgb(
            color
        )

    )


    return tuple(

        (1.0 - amount)
        * rgb

        + amount
        * np.ones(3)

    )


MAIN_LIGHT = lighten_color(

    MAIN_COLOR,

    amount=0.68

)


plt.rcParams.update({

    "font.family":
        "serif",

    "font.serif":
        [PLOT_FONT],

    "mathtext.fontset":
        "stix",

    "font.size":
        13,

    "axes.labelsize":
        16,

    "xtick.labelsize":
        13,

    "ytick.labelsize":
        13,

    "legend.fontsize":
        12,

    "axes.linewidth":
        1.45,

    "axes.edgecolor":
        BLACK,

    "xtick.direction":
        "in",

    "ytick.direction":
        "in",

    "xtick.top":
        False,

    "ytick.right":
        False,

    "xtick.major.width":
        1.2,

    "ytick.major.width":
        1.2,

    "xtick.major.size":
        6,

    "ytick.major.size":
        6,

    "figure.facecolor":
        "white",

    "axes.facecolor":
        "white",

    "savefig.facecolor":
        "white"

})


def style_axis(
    ax
):

    for spine in (
        ax.spines.values()
    ):

        spine.set_visible(
            True
        )

        spine.set_linewidth(
            1.45
        )

        spine.set_color(
            BLACK
        )


    ax.tick_params(

        axis="both",

        which="major",

        direction="in",

        bottom=True,

        top=False,

        left=True,

        right=False,

        width=1.2,

        length=6,

        colors=BLACK

    )


def panel_label(

    ax,

    text

):

    ax.text(

        0.025,

        0.965,

        text,

        transform=ax.transAxes,

        ha="left",

        va="top",

        fontsize=20,

        fontweight="normal",

        color=BLACK,

        zorder=50

    )


def framed_legend(
    ax
):

    legend = ax.legend(

        loc="upper right",

        fontsize=12,

        frameon=True,

        fancybox=False,

        facecolor="white",

        edgecolor=BLACK,

        framealpha=1.0,

        borderpad=0.45,

        labelspacing=0.35,

        handlelength=2.4,

        handletextpad=0.6

    )


    legend.get_frame().set_linewidth(
        0.9
    )


# ============================================================
# 16. Draw figure
# ============================================================

fig, axes = plt.subplots(

    2,

    2,

    figsize=(
        11.2,
        8.4
    ),

    dpi=300

)


plt.subplots_adjust(

    left=0.095,

    right=0.975,

    bottom=0.10,

    top=0.965,

    wspace=0.30,

    hspace=0.34

)


# ------------------------------
# (a) Temperature
# ------------------------------

ax = axes[
    0,
    0
]


ax.plot(

    time_prod,

    temp_prod,

    color=MAIN_COLOR,

    linewidth=0.90

)


ax.axhline(

    TARGET_TEMP,

    color=DARK_GRAY,

    linestyle="--",

    linewidth=1.25

)


ax.text(

    3.94,

    TARGET_TEMP + 13,

    "Target = 800 K",

    ha="right",

    va="bottom",

    fontsize=11.5,

    color=DARK_GRAY

)


ax.text(

    0.97,

    0.94,

    f"mean = {T_mean:.1f} K",

    transform=ax.transAxes,

    ha="right",

    va="top",

    fontsize=13

)


panel_label(
    ax,
    "(a)"
)


ax.set_xlim(
    0,
    4.0
)


ax.set_ylim(
    TEMP_YLIM
)


ax.set_xlabel(
    "Production time (ps)"
)


ax.set_ylabel(
    "Temperature (K)"
)


style_axis(
    ax
)


# ------------------------------
# (b) Total energy
# ------------------------------

ax = axes[
    0,
    1
]


ax.plot(

    time_prod,

    energy_prod,

    color=MAIN_LIGHT,

    linewidth=0.65,

    alpha=0.95,

    label="Instantaneous"

)


if len(
    energy_prod_ma
) > 0:

    ax.plot(

        time_energy_ma,

        energy_prod_ma,

        color=MAIN_COLOR,

        linewidth=1.85,

        label="Moving average"

    )


panel_label(
    ax,
    "(b)"
)


ax.set_xlim(
    0,
    4.0
)


ax.set_xlabel(
    "Production time (ps)"
)


ax.set_ylabel(
    "Total energy E (eV)"
)


style_axis(
    ax
)


framed_legend(
    ax
)


# ------------------------------
# (c) Species-resolved MSD
# ------------------------------

ax = axes[
    1,
    0
]


species_colors = {

    M_element:
        MAIN_COLOR,

    "Ga":
        GA_COLOR,

    "O":
        O_COLOR

}


for element in plot_species:

    ax.plot(

        msd_time,

        msd_species[element],

        color=
            species_colors[element],

        linewidth=
            1.65
            if element == M_element
            else 1.50,

        label=element

    )


panel_label(
    ax,
    "(c)"
)


ax.set_xlim(
    0,
    4.0
)


ax.set_ylim(
    MSD_YLIM
)


ax.set_xlabel(
    "Production time (ps)"
)


ax.set_ylabel(
    "MSD (Å²)"
)


style_axis(
    ax
)


# Put legend outside data area,
# but only slightly above the panel.
ax.legend(

    loc="lower center",

    bbox_to_anchor=(
        0.62,
        1.02
    ),

    ncol=3,

    fontsize=12,

    frameon=False,

    columnspacing=1.2,

    handlelength=2.0,

    handletextpad=0.45,

    borderaxespad=0.0

)


# ------------------------------
# (d) RDF
# ------------------------------

ax = axes[
    1,
    1
]


ax.plot(

    r_MO,

    g_MO,

    color=MAIN_COLOR,

    linewidth=1.80,

    label=f"{M_element}–O"

)


ax.plot(

    r_GaO,

    g_GaO,

    color=GA_COLOR,

    linewidth=1.80,

    label="Ga–O"

)


panel_label(
    ax,
    "(d)"
)


ax.set_xlim(
    0,
    4.3
)


ax.set_ylim(
    RDF_YLIM
)


ax.set_xlabel(
    "r (Å)"
)


ax.set_ylabel(
    "RDF, g(r)"
)


style_axis(
    ax
)


framed_legend(
    ax
)


# ============================================================
# 17. Save figures — ONLY ONCE
# ============================================================

fig.savefig(

    OUTPUT_NAME + ".png",

    dpi=600,

    bbox_inches="tight",

    pad_inches=0.05

)


fig.savefig(

    OUTPUT_NAME + ".pdf",

    bbox_inches="tight",

    pad_inches=0.05

)


fig.savefig(

    OUTPUT_NAME + ".tif",

    dpi=600,

    bbox_inches="tight",

    pad_inches=0.05,

    format="tiff",

    pil_kwargs={

        "compression":
            "tiff_lzw"

    }

)


plt.close(
    fig
)


print()

print(
    "Analysis finished."
)

print(
    "Generated files:"
)

print(
    OUTPUT_NAME + ".png"
)

print(
    OUTPUT_NAME + ".pdf"
)

print(
    OUTPUT_NAME + ".tif"
)

print(
    summary_file
)
