#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AIMD structural-stability analysis for spinel MGa2O4 (M = Mg, Zn, Cd, Hg)

Read:
    - OSZICAR
    - XDATCAR

Generate:
    - AIMD_800K_production_4ps.png
    - AIMD_800K_production_4ps.tif
    - AIMD_800K_production_4ps.pdf
    - AIMD_800K_production_4ps_summary.txt

Figure panels:
    (a) Temperature vs production time
    (b) Total energy vs production time
    (c) Species-resolved MSD
    (d) RDF of M–O and Ga–O

Main settings:
    - Total AIMD trajectory: assumed from OSZICAR/XDATCAR
    - Time step: 1.0 fs
    - Equilibration excluded: first 1.0 ps
    - Production stage: remaining 4.0 ps (for a 5 ps run)
    - High-resolution outputs suitable for manuscripts
"""

import os
import re
import math
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm


# =========================
# User-adjustable settings
# =========================
TIME_STEP_FS = 1.0            # fs
TARGET_TEMPERATURE = 800.0    # K
EQUILIBRATION_PS = 1.0        # ps
MOVING_AVG_WINDOW = 41        # points, for energy smoothing
RDF_BINS = 250
RDF_FRAME_STRIDE = 10         # use every 10th production frame for RDF to save time
DPI_RASTER = 600

# A-site colors
A_COLOR_MAP = {
    "Mg": "#37AD6B",
    "Zn": "#1A6FDF",
    "Cd": "#F14040",
    "Hg": "#8000FF",
}

# Common colors for Ga and O
GA_COLOR = "#D89B00"   # soft orange/golden
O_COLOR  = "#7A8A99"   # soft gray-blue

TARGET_LINE_COLOR = "#555555"

# Figure/label sizes
BASE_FONT_SIZE = 12
AXIS_LABEL_SIZE = 16
TICK_LABEL_SIZE = 12
LEGEND_SIZE = 11
PANEL_LABEL_SIZE = 16
ANNOTATION_SIZE = 12

# Output names
OUT_BASENAME = "AIMD_800K_production_4ps"


# =========================
# Font and style
# =========================
def pick_font():
    """
    Prefer Times New Roman if available; otherwise fall back gracefully.
    """
    candidate_fonts = [
        "Times New Roman",
        "Nimbus Roman",
        "Liberation Serif",
        "DejaVu Serif",
    ]
    available = {f.name for f in fm.fontManager.ttflist}
    for name in candidate_fonts:
        if name in available:
            return name
    return "DejaVu Serif"


PLOT_FONT = pick_font()

mpl.rcParams.update({
    "font.family": PLOT_FONT,
    "mathtext.fontset": "stix",
    "font.size": BASE_FONT_SIZE,
    "axes.labelsize": AXIS_LABEL_SIZE,
    "xtick.labelsize": TICK_LABEL_SIZE,
    "ytick.labelsize": TICK_LABEL_SIZE,
    "legend.fontsize": LEGEND_SIZE,
    "axes.linewidth": 1.2,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.top": False,
    "ytick.right": False,
    "xtick.major.size": 6,
    "xtick.major.width": 1.2,
    "xtick.minor.size": 3,
    "xtick.minor.width": 1.0,
    "ytick.major.size": 6,
    "ytick.major.width": 1.2,
    "ytick.minor.size": 3,
    "ytick.minor.width": 1.0,
})


# =========================
# Utility functions
# =========================
def lighten_color(hex_color, factor=0.55):
    """
    Lighten a hex color by mixing it with white.
    factor in [0,1]: larger -> lighter
    """
    hex_color = hex_color.lstrip("#")
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    r = int(r + (255 - r) * factor)
    g = int(g + (255 - g) * factor)
    b = int(b + (255 - b) * factor)
    return f"#{r:02X}{g:02X}{b:02X}"


def moving_average(y, window=41):
    if window < 2:
        return y.copy()
    if window % 2 == 0:
        window += 1
    pad = window // 2
    ypad = np.pad(y, (pad, pad), mode="edge")
    kernel = np.ones(window, dtype=float) / window
    return np.convolve(ypad, kernel, mode="valid")


def is_int_list(tokens):
    try:
        [int(x) for x in tokens]
        return True
    except Exception:
        return False


def read_oszicar(filename="OSZICAR"):
    """
    Parse temperature and energy from OSZICAR.
    Prefer E0 if available, otherwise F.
    """
    temps = []
    energies = []

    temp_pat = re.compile(r"T=\s*([-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?)")
    e0_pat   = re.compile(r"E0=\s*([-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?)")
    f_pat    = re.compile(r"F=\s*([-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?)")

    with open(filename, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            mt = temp_pat.search(line)
            if mt is None:
                continue

            temps.append(float(mt.group(1)))

            me0 = e0_pat.search(line)
            if me0 is not None:
                energies.append(float(me0.group(1)))
            else:
                mf = f_pat.search(line)
                if mf is not None:
                    energies.append(float(mf.group(1)))
                else:
                    energies.append(np.nan)

    temps = np.array(temps, dtype=float)
    energies = np.array(energies, dtype=float)

    if len(temps) == 0:
        raise RuntimeError("No temperature entries found in OSZICAR.")
    if len(temps) != len(energies):
        raise RuntimeError("Parsed temperature and energy lengths do not match in OSZICAR.")

    return temps, energies


def read_xdatcar(filename="XDATCAR"):
    """
    Read VASP XDATCAR (VASP5-style).
    Return:
        species_names
        species_counts
        lattice (3,3) in Angstrom
        frac_positions (nframes, natoms, 3)
    """
    with open(filename, "r", encoding="utf-8", errors="ignore") as f:
        lines = [line.rstrip() for line in f]

    if len(lines) < 8:
        raise RuntimeError("XDATCAR appears too short.")

    comment = lines[0]
    scale = float(lines[1].split()[0])

    lattice = np.array([
        [float(x) for x in lines[2].split()[:3]],
        [float(x) for x in lines[3].split()[:3]],
        [float(x) for x in lines[4].split()[:3]],
    ], dtype=float)
    lattice *= scale

    # Detect species line and count line
    line6 = lines[5].split()
    line7 = lines[6].split()

    if is_int_list(line6):
        raise RuntimeError("XDATCAR without species names is not supported in this script.")
    elif is_int_list(line7):
        species_names = line6
        species_counts = [int(x) for x in line7]
        start_idx = 7
    else:
        raise RuntimeError("Failed to parse species names/counts from XDATCAR.")

    natoms = sum(species_counts)

    # Read frames
    frames = []
    i = start_idx
    while i < len(lines):
        line = lines[i].strip()
        if ("Direct configuration" in line) or ("Cartesian configuration" in line):
            coords = []
            for j in range(i + 1, i + 1 + natoms):
                xyz = [float(x) for x in lines[j].split()[:3]]
                coords.append(xyz)
            frames.append(coords)
            i += natoms + 1
        else:
            i += 1

    frac_positions = np.array(frames, dtype=float)
    if frac_positions.ndim != 3 or frac_positions.shape[1] != natoms or frac_positions.shape[2] != 3:
        raise RuntimeError("Failed to parse trajectory frames from XDATCAR.")

    return species_names, species_counts, lattice, frac_positions


def unwrap_fractional(frac):
    """
    Sequential PBC unwrapping in fractional coordinates.
    frac shape: (nframes, natoms, 3)
    """
    unwrapped = np.empty_like(frac)
    unwrapped[0] = frac[0]
    for i in range(1, frac.shape[0]):
        d = frac[i] - frac[i - 1]
        d -= np.rint(d)
        unwrapped[i] = unwrapped[i - 1] + d
    return unwrapped


def frac_to_cart(frac, lattice):
    """
    frac (...,3) -> cart (...,3)
    """
    return np.dot(frac, lattice)


def species_index_map(species_names, species_counts):
    """
    Return dict: species -> atom indices
    """
    idx_map = {}
    start = 0
    for sp, n in zip(species_names, species_counts):
        idx_map[sp] = np.arange(start, start + n, dtype=int)
        start += n
    return idx_map


def compute_species_msd(cart_unwrapped_prod, ref_cart, idx_map):
    """
    cart_unwrapped_prod: (nprod, natoms, 3)
    ref_cart: (natoms, 3), reference frame (first production frame)
    Return dict species -> MSD(t)
    """
    disp = cart_unwrapped_prod - ref_cart[None, :, :]
    sq = np.sum(disp ** 2, axis=2)  # (nprod, natoms)

    out = {}
    for sp, idx in idx_map.items():
        out[sp] = np.mean(sq[:, idx], axis=1)
    return out


def compute_rdf(frac_prod, lattice, idx_i, idx_j, nbins=250, rmax=None, stride=10):
    """
    Compute RDF g_ij(r) for distinct groups i and j.
    frac_prod: (nframes, natoms, 3), wrapped fractional coords
    """
    if rmax is None:
        vec_lengths = np.linalg.norm(lattice, axis=1)
        rmax = 0.5 * np.min(vec_lengths) - 0.02

    volume = abs(np.linalg.det(lattice))
    rho_j = len(idx_j) / volume

    edges = np.linspace(0.0, rmax, nbins + 1)
    hist = np.zeros(nbins, dtype=float)
    nframes_used = 0

    idx_i = np.asarray(idx_i, dtype=int)
    idx_j = np.asarray(idx_j, dtype=int)

    for iframe in range(0, frac_prod.shape[0], stride):
        fi = frac_prod[iframe, idx_i, :]   # (Ni, 3)
        fj = frac_prod[iframe, idx_j, :]   # (Nj, 3)

        df = fj[None, :, :] - fi[:, None, :]   # (Ni, Nj, 3)
        df -= np.rint(df)                      # minimum image in fractional coords
        dr = np.dot(df, lattice)               # (Ni, Nj, 3)
        dist = np.linalg.norm(dr, axis=2).ravel()

        h, _ = np.histogram(dist, bins=edges)
        hist += h
        nframes_used += 1

    r = 0.5 * (edges[:-1] + edges[1:])
    dr_bin = edges[1] - edges[0]
    shell_vol = 4.0 * np.pi * r**2 * dr_bin

    norm = nframes_used * len(idx_i) * rho_j * shell_vol
    g_r = hist / norm

    return r, g_r, nframes_used


def add_panel_label(ax, label):
    ax.text(
        0.02, 0.96, label,
        transform=ax.transAxes,
        ha="left", va="top",
        fontsize=PANEL_LABEL_SIZE,
        fontweight="normal"
    )


def style_axis(ax):
    ax.tick_params(which="both", top=False, right=False)
    for spine in ax.spines.values():
        spine.set_linewidth(1.2)


def write_summary(
    outfile,
    a_site,
    natoms,
    total_time_ps,
    prod_time_ps,
    mean_T,
    std_T,
    msd_dict,
):
    lines = []
    lines.append("=============================================")
    lines.append("AIMD 800 K structural-stability analysis")
    lines.append("=============================================")
    lines.append("")
    lines.append(f"Material A-site element : {a_site}")
    lines.append(f"Number of atoms         : {natoms}")
    lines.append(f"Time step               : {TIME_STEP_FS:.3f} fs")
    lines.append(f"Target temperature      : {TARGET_TEMPERATURE:.1f} K")
    lines.append(f"Total AIMD time         : {total_time_ps:.3f} ps")
    lines.append(f"Equilibration excluded  : {EQUILIBRATION_PS:.3f} ps")
    lines.append(f"Production time         : {prod_time_ps:.3f} ps")
    lines.append("")
    lines.append("Production-stage temperature")
    lines.append(f"Mean T                  : {mean_T:.2f} K")
    lines.append(f"Standard deviation      : {std_T:.2f} K")
    lines.append("")
    lines.append("Species-resolved MSD")

    for sp, arr in msd_dict.items():
        final_val = arr[-1]
        late_half = arr[len(arr)//2:]
        mean_late = np.mean(late_half)
        lines.append(f"{sp:>2s} final MSD            : {final_val:.6f} Å²")
        lines.append(f"{sp:>2s} mean MSD (late half) : {mean_late:.6f} Å²")

    with open(outfile, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


# =========================
# Main
# =========================
def main():
    print("Reading OSZICAR ...")
    temps, energies = read_oszicar("OSZICAR")
    nsteps_osz = len(temps)
    print(f"OSZICAR steps : {nsteps_osz}")

    total_time_ps = (nsteps_osz - 1) * TIME_STEP_FS / 1000.0
    print(f"Total time    : {total_time_ps:.3f} ps")

    print("Reading XDATCAR ...")
    species_names, species_counts, lattice, frac = read_xdatcar("XDATCAR")
    natoms = sum(species_counts)
    print(f"Species       : {species_names}")
    print(f"Atom counts   : {species_counts}")
    print(f"Total atoms   : {natoms}")
    print(f"XDATCAR frames: {frac.shape[0]}")

    nsteps = min(nsteps_osz, frac.shape[0])
    temps = temps[:nsteps]
    energies = energies[:nsteps]
    frac = frac[:nsteps]

    print("Performing sequential PBC unwrapping ...")
    frac_unwrapped = unwrap_fractional(frac)
    cart_unwrapped = frac_to_cart(frac_unwrapped, lattice)

    idx_map = species_index_map(species_names, species_counts)

    # identify A-site element
    a_site_candidates = [sp for sp in species_names if sp not in ("Ga", "O")]
    if len(a_site_candidates) != 1:
        raise RuntimeError("Failed to identify a unique A-site element.")
    a_site = a_site_candidates[0]
    print(f"A-site element : {a_site}")

    a_color = A_COLOR_MAP.get(a_site, "#1F77B4")
    instant_color = lighten_color(a_color, factor=0.65)

    # production slice
    eq_steps = int(round(EQUILIBRATION_PS * 1000.0 / TIME_STEP_FS))
    if eq_steps >= nsteps - 2:
        raise RuntimeError("Equilibration range is too long for the available trajectory.")

    prod_slice = slice(eq_steps, nsteps)
    t_prod = (np.arange(eq_steps, nsteps) - eq_steps) * TIME_STEP_FS / 1000.0
    prod_time_ps = t_prod[-1]

    temps_prod = temps[prod_slice]
    energy_prod = energies[prod_slice]
    frac_prod = frac[prod_slice]
    cart_unwrapped_prod = cart_unwrapped[prod_slice]

    ref_cart = cart_unwrapped[eq_steps]
    msd_dict = compute_species_msd(cart_unwrapped_prod, ref_cart, idx_map)

    mean_T = np.mean(temps_prod)
    std_T = np.std(temps_prod)

    # RDF
    print(f"RDF uses every {RDF_FRAME_STRIDE}th production frame.")
    r_mo, g_mo, nframes_rdf = compute_rdf(
        frac_prod, lattice, idx_map[a_site], idx_map["O"],
        nbins=RDF_BINS, stride=RDF_FRAME_STRIDE
    )
    r_go, g_go, _ = compute_rdf(
        frac_prod, lattice, idx_map["Ga"], idx_map["O"],
        nbins=RDF_BINS, stride=RDF_FRAME_STRIDE
    )

    # Energy moving average
    energy_smooth = moving_average(energy_prod, MOVING_AVG_WINDOW)

    # print summary to screen
    print("")
    print("=============================================")
    print("AIMD 800 K structural-stability analysis")
    print("=============================================")
    print("")
    print(f"Material A-site element : {a_site}")
    print(f"Number of atoms         : {natoms}")
    print(f"Time step               : {TIME_STEP_FS:.3f} fs")
    print(f"Target temperature      : {TARGET_TEMPERATURE:.1f} K")
    print(f"Total AIMD time         : {total_time_ps:.3f} ps")
    print(f"Equilibration excluded  : {EQUILIBRATION_PS:.3f} ps")
    print(f"Production time         : {prod_time_ps:.3f} ps")
    print("")
    print("Production-stage temperature")
    print(f"Mean T                  : {mean_T:.2f} K")
    print(f"Standard deviation      : {std_T:.2f} K")
    print("")
    print("Species-resolved MSD")
    for sp, arr in msd_dict.items():
        final_val = arr[-1]
        late_half = arr[len(arr)//2:]
        mean_late = np.mean(late_half)
        print(f"{sp:>2s} final MSD            : {final_val:.6f} Å²")
        print(f"{sp:>2s} mean MSD (late half) : {mean_late:.6f} Å²")

    print(f"Plot font      : {PLOT_FONT}")

    # =========================
    # Plot
    # =========================
    fig, axes = plt.subplots(2, 2, figsize=(11.2, 8.3))
    ax1, ax2, ax3, ax4 = axes.ravel()

    # (a) Temperature
    ax1.plot(t_prod, temps_prod, color=a_color, lw=1.0)
    ax1.axhline(TARGET_TEMPERATURE, color=TARGET_LINE_COLOR, lw=1.2, ls="--")
    ax1.set_xlabel("Production time (ps)")
    ax1.set_ylabel("Temperature (K)")
    add_panel_label(ax1, "(a)")
    ax1.text(
        0.98, 0.95, f"mean = {mean_T:.1f} K",
        transform=ax1.transAxes, ha="right", va="top",
        fontsize=ANNOTATION_SIZE
    )
    ax1.text(
        0.98, 0.56, f"Target = {TARGET_TEMPERATURE:.0f} K",
        transform=ax1.transAxes, ha="right", va="center",
        fontsize=ANNOTATION_SIZE - 1, color=TARGET_LINE_COLOR
    )
    style_axis(ax1)

    # (b) Energy
    ax2.plot(t_prod, energy_prod, color=instant_color, lw=0.9, label="Instantaneous")
    ax2.plot(t_prod, energy_smooth, color=a_color, lw=1.8, label="Moving average")
    ax2.set_xlabel("Production time (ps)")
    ax2.set_ylabel("Total energy E (eV)")
    add_panel_label(ax2, "(b)")
    leg2 = ax2.legend(
        loc="upper right", frameon=True, fancybox=False,
        framealpha=1.0, edgecolor="black", facecolor="white"
    )
    style_axis(ax2)

    # (c) MSD
    ax3.plot(t_prod, msd_dict[a_site], color=a_color, lw=1.8, label=a_site)
    ax3.plot(t_prod, msd_dict["Ga"], color=GA_COLOR, lw=1.6, label="Ga")
    ax3.plot(t_prod, msd_dict["O"],  color=O_COLOR,  lw=1.6, label="O")
    ax3.set_xlabel("Production time (ps)")
    ax3.set_ylabel("MSD (Å$^2$)")
    add_panel_label(ax3, "(c)")
    ax3.legend(
        loc="upper right", frameon=True, fancybox=False,
        framealpha=1.0, edgecolor="black", facecolor="white"
    )
    style_axis(ax3)

    # (d) RDF
    ax4.plot(r_mo, g_mo, color=a_color, lw=1.8, label=f"{a_site}–O")
    ax4.plot(r_go, g_go, color=GA_COLOR, lw=1.8, label="Ga–O")
    ax4.set_xlabel("r (Å)")
    ax4.set_ylabel("RDF, g(r)")
    add_panel_label(ax4, "(d)")
    ax4.legend(
        loc="upper right", frameon=True, fancybox=False,
        framealpha=1.0, edgecolor="black", facecolor="white"
    )
    style_axis(ax4)

    # x-range
    ax1.set_xlim(t_prod[0], t_prod[-1])
    ax2.set_xlim(t_prod[0], t_prod[-1])
    ax3.set_xlim(t_prod[0], t_prod[-1])
    ax4.set_xlim(0.0, max(r_mo.max(), r_go.max()))

    # tidy layout
    plt.subplots_adjust(left=0.09, right=0.98, bottom=0.09, top=0.97, wspace=0.28, hspace=0.24)

    # save figure
    png_file = f"{OUT_BASENAME}.png"
    tif_file = f"{OUT_BASENAME}.tif"
    pdf_file = f"{OUT_BASENAME}.pdf"
    txt_file = f"{OUT_BASENAME}_summary.txt"

    fig.savefig(png_file, dpi=DPI_RASTER, bbox_inches="tight")
    fig.savefig(tif_file, dpi=DPI_RASTER, bbox_inches="tight")
    fig.savefig(pdf_file, bbox_inches="tight")
    plt.close(fig)

    # save summary
    write_summary(
        txt_file,
        a_site=a_site,
        natoms=natoms,
        total_time_ps=total_time_ps,
        prod_time_ps=prod_time_ps,
        mean_T=mean_T,
        std_T=std_T,
        msd_dict=msd_dict,
    )

    print("")
    print("Analysis finished.")
    print("Generated files:")
    print(png_file)
    print(pdf_file)
    print(tif_file)
    print(txt_file)


if __name__ == "__main__":
    main()
